package miniapp;

import java.io.FileNotFoundException;

public interface Employee {
	
	public void addEmployee(Emp e) throws  UserException;

}
