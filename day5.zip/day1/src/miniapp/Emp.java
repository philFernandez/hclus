package miniapp;

public class Emp {
	
	private String empName;
	private String empCity;
	public Emp(String empName, String empCity) {
		super();
		this.empName = empName;
		this.empCity = empCity;
	}

}
