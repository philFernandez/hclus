package mypack;

public class AbsMain {
	public static void main(String[] args) {
		
		AbstratctDemo abstratctDemo= new AbstractMain();
    // abstratctDemo.demo1();
	}

}
