package mypack;

public class AbstractMain extends AbstratctDemo{

	@Override
	public void demo1() {
		// TODO Auto-generated method stub
		
	}

	public AbstractMain() {
		System.out.println("inside main");
		// TODO Auto-generated constructor stub
	}

	@Override
	public void demo3() {
		// TODO Auto-generated method stub
		
	}

}
