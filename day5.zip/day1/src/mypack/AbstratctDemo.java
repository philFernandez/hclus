package mypack;

public abstract class AbstratctDemo {

	public AbstratctDemo() {
		System.out.println("inside cons");
	}
	
	public abstract void demo1();
	
	public void demo2() {
		System.out.println("default call");
	}
	public abstract void demo3();
	
	
}
