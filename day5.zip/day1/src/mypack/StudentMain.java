package mypack;

public class StudentMain {
	public static void main(String[] args) {
		
		
		Student student= new Student();
		
		 
		Student student2= new Student("admin","mumbai",1);
		
		
		System.out.println(student2);
		
		
	}

}
