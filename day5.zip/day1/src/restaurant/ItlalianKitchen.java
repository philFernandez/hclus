package restaurant;

public class ItlalianKitchen implements Kitchen{

	@Override
	public String cookFood(String foodName) {
		// TODO Auto-generated method stub
		return "Food is prepared by Italian Kitchen with dish " + foodName;
	}
	}


