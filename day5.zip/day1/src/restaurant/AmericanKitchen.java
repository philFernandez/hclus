package restaurant;

public class AmericanKitchen implements Kitchen {

	@Override
	public String cookFood(String foodName) {
		// TODO Auto-generated method stub
		return "Food is prepared by American Kitchen with dish " + foodName;
	}

}
