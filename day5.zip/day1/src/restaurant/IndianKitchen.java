package restaurant;

public class IndianKitchen implements Kitchen{

	@Override
	public String cookFood(String foodName) {
		// TODO Auto-generated method stub
		return "Food is prepared by Indian Kitchen with dish " + foodName;
	}

}
