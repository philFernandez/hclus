package restaurant;

public interface Kitchen {
	
	public String cookFood(String foodName);

}
