package interfacedemo;

public class MainDemo {
	public static void main(String[] args) {
		
		Bank bank= new PublicBanks();
		Bank bank2= new PrivateBank();
		
		
	}

}
