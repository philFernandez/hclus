package interfacedemo;

public interface Bank2 {
	
	public void m2();

}
