package interfacedemo;

public interface Bank {
	
	public static final int MIN_BALANCE=500;
	
	public void withdraw();
	public void deposit();
	
	

}
